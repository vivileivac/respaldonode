import { Component } from '@angular/core';

@Component({
  selector: 'app-reporte',
  imports: [],
  templateUrl: './reporte.html',
  styleUrl: './reporte.css',
})
export class Reporte {

}
