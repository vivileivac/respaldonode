import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Router, RouterModule } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { FiscalizacionPlanificar } from '../../services/fiscalizacion-planificar';
import { Global } from '../../services/global';


@Component({
  standalone: true,
  selector: 'app-fiscalizacion',
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './fiscalizacion.html',
  styleUrl: './fiscalizacion.css'
})
export class Fiscalizacion {


  concesiones: any[] = [];

  constructor(
    private fiscalizacionservice: FiscalizacionPlanificar,
    private global: Global,
    private router: Router,
    private fb: FormBuilder,

  ) { }

  ngOnInit(): void {

    this.global.setUsuario({
      CDReparticion: 2,
      NRRutUsuario: 10181360
    });

    this.cargarBoard(this.global.getReparticion()); // ejemplo repa

  }

  Seleccionados: any[] = [];

  toggleTramite(tramite: any, checked: boolean) {
    if (checked) {
      this.Seleccionados.push(tramite);
    } else {
      this.Seleccionados = this.Seleccionados.filter(
        t => t.IDTramite !== tramite.IDTramite
      );
    }
  }
  // habilitar botón
  get algunoSeleccionado(): boolean {
    return this.Seleccionados.length > 0;
  }
estaSeleccionado(id: number): boolean {
  return this.Seleccionados.some(t => t.IDTramite === id);
}
claseEstado(estado: number): string {
  switch (+estado) {
    case 1: return 'text-info';   // Sin Observaciones
 //   case 2: return 'text-warning';   // Sin proceso
    //case 3: return 'text-info';      // En proceso
    case 4: return 'text-danger';    // Con Observaciones
    default: return 'text-warning';
  }
}

ingresar(Con: any){

}

marcarNoFiscalizado(Con: any){

}


  guardarSeleccion() {

    this.fiscalizacionservice.setConcesionesSeleccionadas(this.Seleccionados);

    this.router.navigate(['/planificacion']);
  }



  private cargarBoard(repa: number): void {
    this.fiscalizacionservice.recuperarBoard(repa)
      .subscribe({
        next: (res: any) => {
          console.log('los datos:', res);
          this.concesiones = Array.isArray(res.data) ? res.data : [];
          console.log('CONCESIONES:', this.concesiones);
        },
        error: (err: any) => {
          console.error('Error al recuperar board', err);
        }
      });
  }

  diasAMeses(dias: number | null): number {
    if (!dias || dias <= 0) return 24;
    return Math.ceil(dias / 30);
  }


  colorPorMeses(meses: number): string {
    if (meses < 6) return '#198754';      // verde
    if (meses < 12) return '#ffc107';     // amarillo
    return '#dc3545';                     // rojo
  }
}
