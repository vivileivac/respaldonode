// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { Home } from './pages/home/home';
import { Fiscalizacion } from './pages/fiscalizacion/fiscalizacion';
import { Formulario } from './pages/formulario/formulario';
import { Reporte } from './pages/reporte/reporte';
import { Planificacion } from './pages/planificacion/planificacion';

export const routes: Routes = [
  // Página inicial
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  // Páginas principales
  { path: 'home', component: Home },
  { path: 'fiscalizacion', component: Fiscalizacion },
  { path: 'formulario', component: Formulario },
  { path: 'reporte', component: Reporte },
  { path: 'planificacion', component: Planificacion },

  // Ruta comodín: cualquier ruta no existente redirige a home
  { path: '**', redirectTo: 'home' }
];
