import { TestBed } from '@angular/core/testing';

import { FiscalizacionPlanificar } from './fiscalizacion-planificar';

describe('FiscalizacionPlanificar', () => {
  let service: FiscalizacionPlanificar;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FiscalizacionPlanificar);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
