import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dialogo-simple',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule
  ],
  template: `
  <h2 mat-dialog-title>{{ data.titulo }}</h2>

  <div mat-dialog-content>
    {{ data.mensaje }}
  </div>

  <div mat-dialog-actions align="end">

    <!-- Cancelar solo si cancelar !== false -->
    <button
      *ngIf="data.cancelar !== false"
      mat-button
      [mat-dialog-close]="false">
      Cancelar
    </button>

    <button
      mat-raised-button
      color="primary"
      [mat-dialog-close]="true">
      Aceptar
    </button>

  </div>
`

})
export class DialogoSimple {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}
}
