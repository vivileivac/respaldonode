import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UsuarioGlobal } from '../models/usuario-global';

@Injectable({
  providedIn: 'root',
})
export class Global {
  constructor(private http: HttpClient, private router: Router) { }

    private usuario: UsuarioGlobal = {
    CDReparticion: 0,
    NRRutUsuario: 0
  };

  setUsuario(data: UsuarioGlobal) {
    this.usuario = data;
  }

  getUsuario(): UsuarioGlobal {
    return this.usuario;
  }

  getReparticion(): number {
    return this.usuario.CDReparticion;
  }

  getRut(): number {
    return this.usuario.NRRutUsuario;
  }

}
