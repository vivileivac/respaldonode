import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { DialogoSimple } from '../../shared/components/dialogo-simple';
import { Router, RouterModule } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { ContextoFiscalizada } from '../../models/contextoFiscalizada';
import { FiscalizacionPlanificar } from '../../services/fiscalizacion-planificar';
import { Global } from '../../services/global';


@Component({
  standalone: true,
  selector: 'app-fiscalizacion',
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './fiscalizacion.html',
  styleUrl: './fiscalizacion.css'
})
export class Fiscalizacion {


  concesiones: any[] = [];

  constructor(
    private fiscalizacionservice: FiscalizacionPlanificar,
    private global: Global,
    private router: Router,
    private fb: FormBuilder,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {

    this.global.setUsuario({
      CDReparticion: 2,
      NRRutUsuario: 10181360
    });

    this.cargarBoard(this.global.getReparticion()); // ejemplo repa

  }

  Seleccionados: any[] = [];

  toggleTramite(tramite: any, checked: boolean) {
    if (checked) {
      this.Seleccionados.push(tramite);
    } else {
      this.Seleccionados = this.Seleccionados.filter(
        t => t.IDTramite !== tramite.IDTramite
      );
    }
  }
  // habilitar botón
  get algunoSeleccionado(): boolean {
    return this.Seleccionados.length > 0;
  }
  estaSeleccionado(id: number): boolean {
    return this.Seleccionados.some(t => t.IDTramite === id);
  }
  claseEstado(estado: number): string {
    switch (+estado) {
      case 1: return 'text-info';   // Sin Observaciones
      //   case 2: return 'text-warning';   // Sin proceso
      //case 3: return 'text-info';      // En proceso
      case 4: return 'text-danger';    // Con Observaciones
      default: return 'text-warning';
    }
  }



  irAIngreso(detalle: ContextoFiscalizada) {

    this.fiscalizacionservice.setContexto(detalle);
    this.router.navigate(['/ingreso']);
  }

 actualizarEstado(estado: number, detalle: any) {
    // Abrir diálogo de confirmación
    const dialogRef = this.dialog.open(DialogoSimple, {
      width: '350px',
      data: {
        titulo: 'Confirmar acción',
        mensaje: `¿Estás seguro de cambiar el estado a "${this.getObservacion(estado)}"?`,
        cancelar: true // muestra el botón cancelar
      }
    });

    // Esperar cierre del diálogo
    dialogRef.afterClosed().subscribe((confirmado: boolean) => {
      if (!confirmado) return; // si el usuario canceló, no hacemos nada

      const observaciones: any = {
        2: 'En Curso',
        3: 'Fiscalización realizada',
        4: 'Planificada no realizada'
      };

      const payload = {
        IDDetallePlanificacion: detalle.IDDetallePlanificacion,
        CDTPEstadoPlan: estado,
        GLObservacion: observaciones[estado] || null,
        NRRutUsuario: this.global.getRut(),
        FCEjecucion: null
      };

      this.fiscalizacionservice.crearPlanificacion(payload).subscribe({
        next: (resp: any) => {
          console.log('Estado creado correctamente', resp);
          this.cargarBoard(this.global.getReparticion());
        },
        error: (err : any) => {
          console.error('Error al crear estado', err);
        }
      });
    });
  }

    // Método helper para mostrar la observación legible
  getObservacion(estado: number): string {
    const observaciones: any = {
      2: 'En Curso',
      3: 'Fiscalización realizada',
      4: 'Planificada no realizada'
    };
    return observaciones[estado] || 'Desconocido';
  }


  guardarSeleccion() {

    this.fiscalizacionservice.setConcesionesSeleccionadas(this.Seleccionados);

    this.router.navigate(['/planificacion']);
  }



  private cargarBoard(repa: number): void {
    this.fiscalizacionservice.recuperarBoard(repa)
      .subscribe({
        next: (res: any) => {
          console.log('los datos:', res);
          this.concesiones = Array.isArray(res.data) ? res.data : [];
          console.log('CONCESIONES:', this.concesiones);
        },
        error: (err: any) => {
          console.error('Error al recuperar board', err);
        }
      });
  }

 
  // helpers para meses

  diasAMeses(dias: number | null): number {
    if (!dias || dias <= 0) return 24;
    return Math.ceil(dias / 30);
  }

  /* ================================
     BANDERAS → SOLO ESTADO
  ================================ */

  claseBandera(estado: number | null): string {

    switch (Number(estado)) {
      case 1: return 'text-primary';   // Planificada
      case 2: return 'text-warning';   // En curso
      case 3: return 'text-success';   // Finalizada
      case 4: return 'text-danger';    // Planificada no realizada
      default: return 'text-muted';
    }
  }

  /* ================================
     📊 BARRA → SOLO MESES
  ================================ */

  claseBarraPorMeses(meses: number): string {

    if (meses <= 3) return 'bg-info';       // pocos meses
    if (meses <= 6) return 'bg-primary';    // medio año
    if (meses <= 12) return 'bg-warning';   // alto
    return 'bg-danger';                     // sobre 1 año
  }
}
