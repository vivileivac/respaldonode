import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { DialogoSimple } from '../../shared/components/dialogo-simple';
import { Router, RouterModule } from '@angular/router';


import { FormArray, FormBuilder, FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { FiscalizacionPlanificar } from '../../services/FiscalizacionPlanificar';
import { Global } from '../../services/global';
import { ItemFiscalizacion } from '../../models/item-fiscalizacion';
import { ContextoFiscalizada } from '../../models/contextoFiscalizada';



@Component({
  standalone: true,
  selector: 'app-ingreso',
  imports: [CommonModule,
    ReactiveFormsModule,
    RouterModule],
  templateUrl: './ingreso.html',
  styleUrl: './ingreso.css',
})

export class Ingreso {



  contexto!: ContextoFiscalizada;
  items: ItemFiscalizacion[] = [];
  form!: FormGroup;

  constructor(
    private fiscalizacionService: FiscalizacionPlanificar,
    private global: Global,
    private router: Router,
    private fb: FormBuilder,
    private dialog: MatDialog

  ) { }

  ngOnInit() {

    const ctx = this.fiscalizacionService.getContexto();
    if (!ctx) {
      this.router.navigate(['/fiscalizacion']);
      return;
    }

    this.contexto = ctx;




    this.global.obtenerItemsFiscalizacion()
      .subscribe({
        next: (resp) => {
          this.items = resp;
          this.crearFormulario();
        },
        error: (err) => console.error(err)
      });


  }



  crearFormulario() {

    this.form = this.fb.group({
      respuestas: this.fb.array(
        this.items.map(item =>
          this.fb.group({
            IDItem: [item.IDItemFiscalizacion],
            Cumple: [null]   // aquí el usuario marcará Sí o No
          })
        )
      )
    });

  }


  get respuestas(): FormArray {
    return this.form.get('respuestas') as FormArray;
  }

  get itemsArray(): FormArray {
  return this.form.get('items') as FormArray;
}

}
