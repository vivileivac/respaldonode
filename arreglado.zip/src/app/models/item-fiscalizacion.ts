// src/app/models/item-fiscalizacion.model.ts
export interface ItemFiscalizacion {

  IDItemFiscalizacion: number,
  CDTPFiscalizacion: number,
  GLTPFiscalizacion: string,
  NROrden: number,
  GLTPItem: string
}
