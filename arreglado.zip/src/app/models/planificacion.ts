export interface PlanificacionDetalle {
  IDConcesion: number;
  FCFiscalizacion: string;
  CDTPEstadoPlan: number;
  FCEjecucion: string;
}

export interface PlanificacionPayload {
  CDReparticion: number;
  FCPlanificada: string;
  NRRutUsuario: number;
  detalles: PlanificacionDetalle[];
}
