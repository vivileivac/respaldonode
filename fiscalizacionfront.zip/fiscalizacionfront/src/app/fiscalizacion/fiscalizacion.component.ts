import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  Renderer2,
  Inject,
} from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-fiscalizacion',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './fiscalizacion.component.html',
  styleUrls: ['./fiscalizacion.component.css'],
})
export class FiscalizacionComponent implements OnInit, AfterViewInit, OnDestroy {
  private destroy$ = new Subject<void>();

  // --- Tooltips (SSR-safe) ---
  private isBrowser: boolean;
  private tooltipCtor: ((new (el: Element, options?: any) => any) | null) = null;
  private tooltipInstances: any[] = [];

  constructor(
    private el: ElementRef,
    private renderer: Renderer2,
    private router: Router,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
  }

  ngOnInit(): void {
    // Re-inicia y anima al volver a este componente
    this.router.events
      .pipe(
        filter((e): e is NavigationEnd => e instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        if (!this.isBrowser) return; // ✅ no ejecutar en SSR
        this.restartAndAnimate();
        this.refreshTooltips(); // re-inicializa tooltips tras navegación
      });
  }

  async ngAfterViewInit(): Promise<void> {
    if (!this.isBrowser) return; // ✅ no ejecutar en SSR
    this.restartAndAnimate();
    await this.initTooltips(); // inicializa tooltips al montar
  }

  ngOnDestroy(): void {
    this.disposeTooltips();
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ---------------- Tooltips Bootstrap (SSR-safe) ----------------

  /** Carga Bootstrap dinámicamente y crea los tooltips (sólo en browser). */
  private async initTooltips(): Promise<void> {
    if (!this.isBrowser) return;

    // Import dinámico para evitar que SSR evalúe bootstrap (usa el bundle con Popper)
    const bs = await import('bootstrap');
    this.tooltipCtor = (bs as any).Tooltip;

    const nodes = this.el.nativeElement.querySelectorAll('[data-bs-toggle="tooltip"]');
    this.tooltipInstances = Array.from(nodes as NodeListOf<Element>).map(
      (el) =>
        new this.tooltipCtor!(el, {
          trigger: 'hover focus',
          container: 'body',
        })
    );
  }

  /** Elimina instancias actuales de tooltips. */
  private disposeTooltips(): void {
    this.tooltipInstances.forEach((t) => t?.dispose?.());
    this.tooltipInstances = [];
  }

  /** Limpia e inicializa nuevamente (útil tras cambios de DOM o navegación). */
  private async refreshTooltips(): Promise<void> {
    this.disposeTooltips();
    await this.initTooltips();
  }

  // ---------------- Core (barras) ----------------

  /** Reinicia todas las barras a 0% y luego anima al valor objetivo. */
  private restartAndAnimate(): void {
    const bars: NodeListOf<HTMLElement> =
      this.el.nativeElement.querySelectorAll('.progress-bar');

    const reduceMotion =
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // 1) Preparar todas (0%, label 0%, color base)
    bars.forEach((bar) => this.prepareBar(bar));

    // 2) Animar todas (dos rAF para asegurar layout estable)
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        bars.forEach((bar) => this.runAnimation(bar, reduceMotion));
      });
    });
  }

  private prepareBar(bar: HTMLElement): void {
    const max = this.getMax(bar);

    // Reset visual y aria
    this.renderer.setStyle(bar, 'width', '0%');
    this.renderer.setAttribute(bar, 'aria-valuenow', '0');

    // Color inicial (tramo 0–6 = verde)
    this.applyColor(bar, 0);

    const label = bar.querySelector('.bar-label') as HTMLElement | null;
    if (label) label.textContent = `0 / ${max} (0%)`;

    // Marca de tramo para evitar repintados innecesarios durante la animación
    (bar.dataset as any).range = String(this.getRangeIndex(0));
  }

  private runAnimation(bar: HTMLElement, reduceMotion: boolean): void {
    const max = this.getMax(bar);
    const target = this.getTarget(bar);
    const targetClamped = Math.max(0, Math.min(max, target));
    const targetPct = max > 0 ? (targetClamped / max) * 100 : 0;
    const label = bar.querySelector('.bar-label') as HTMLElement | null;

    if (reduceMotion) {
      // Accesibilidad: sin animación
      this.renderer.setStyle(bar, 'width', `${targetPct}%`);
      this.renderer.setAttribute(bar, 'aria-valuenow', String(targetClamped));
      this.applyColor(bar, targetClamped);
      if (label) label.textContent = `${targetClamped} / ${max} (${Math.round(targetPct)}%)`;
      (bar.dataset as any).range = String(this.getRangeIndex(targetClamped));
      return;
    }

    const duration = 1200; // ms
    const start = performance.now();

    const step = (now: number) => {
      const elapsed = now - start;
      const t = Math.min(elapsed / duration, 1); // 0 → 1
      const eased = this.easeOutCubic(t);

      const currentVal = Math.round(targetClamped * eased);
      const currentPct = max > 0 ? (currentVal / max) * 100 : 0;

      this.renderer.setStyle(bar, 'width', `${currentPct}%`);
      this.renderer.setAttribute(bar, 'aria-valuenow', String(currentVal));

      // Cambia color solo si cruzamos umbral
      const prevRange = Number((bar.dataset as any).range ?? '-1');
      const newRange = this.getRangeIndex(currentVal);
      if (newRange !== prevRange) {
        this.applyColor(bar, currentVal);
        (bar.dataset as any).range = String(newRange);
      }

      if (label) label.textContent = `${currentVal} / ${max} (${Math.round(currentPct)}%)`;

      if (t < 1) {
        requestAnimationFrame(step);
      } else {
        // Estado final exacto
        this.renderer.setStyle(bar, 'width', `${targetPct}%`);
        this.renderer.setAttribute(bar, 'aria-valuenow', String(targetClamped));
        this.applyColor(bar, targetClamped);
        if (label) label.textContent = `${targetClamped} / ${max} (${Math.round(targetPct)}%)`;
        (bar.dataset as any).range = String(this.getRangeIndex(targetClamped));
      }
    };

    requestAnimationFrame(step);
  }

  // ---------------- Helpers ----------------

  private getMax(bar: HTMLElement): number {
    const attr = bar.getAttribute('aria-valuemax');
    const max = attr ? parseInt(attr, 10) : 100;
    return Number.isFinite(max) ? max : 100;
  }

  private getTarget(bar: HTMLElement): number {
    const data = bar.getAttribute('data-progress');
    const aria = bar.getAttribute('aria-valuenow');
    const val = data ?? aria ?? '0';
    const n = parseInt(val, 10);
    return Number.isFinite(n) ? n : 0;
  }

  private easeOutCubic(t: number): number {
    return 1 - Math.pow(1 - t, 3);
  }

  // ---------------- Colores por tramo ----------------

  /** 0: verde (0–6), 1: amarillo (7–12), 2: naranjo (13–18), 3: rojo (19–24+) */
  private getRangeIndex(meses: number): number {
    if (meses <= 6) return 0;
    if (meses <= 12) return 1;
    if (meses <= 18) return 2;
    return 3;
  }

  private colorForMonths(meses: number): string {
    const v = Math.max(0, meses);
    if (v <= 6) return '#22c55eab'; // verde
    if (v <= 12) return '#eab308ab'; // amarillo
    if (v <= 18) return '#f97316ab'; // naranjo
    return '#ef4444ab'; // rojo
  }

  private applyColor(bar: HTMLElement, meses: number): void {
    const color = this.colorForMonths(meses);
    this.renderer.setStyle(bar, 'background-color', color);
    this.renderer.setStyle(bar, 'color', '#fff');
  }
}
