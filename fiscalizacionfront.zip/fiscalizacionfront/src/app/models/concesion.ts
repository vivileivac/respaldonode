export interface Concesion {
  GLTPEstadoPlan: string;
  NRKardex: number;
  IDTramite: number;
  FCDecreto: string;
  GLTPComuna: string;
  GLSector: string;
  IDConcesion: number;
  CDReparticion: number;
  CDTPComuna: number;
  GLReparticion: string;
  FCFiscalizacion: string;
  DiasdeInsp: number;
  estadoColor: string;
  BotonIngresar: number;
  CDTPEstadoPlan: number;
  IDPlanificacion: number;
  IDDetallePlanificacion: number;
}
