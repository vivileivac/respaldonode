export interface UsuarioGlobal {
  CDReparticion: number;
  NRRutUsuario: number;
}
