export interface ContextoFiscalizada {
  IDPlanificacion: number,
  IDDetallePlanificacion: number,
  GLSector: string,
}
