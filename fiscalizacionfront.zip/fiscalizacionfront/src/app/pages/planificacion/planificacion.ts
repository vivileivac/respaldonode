import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { FiscalizacionPlanificar } from '../../services/FiscalizacionPlanificar';
import { Global } from '../../services/global';
import { Concesion } from '../../models/concesion';
import { PlanificacionPayload } from '../../models/planificacion';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DialogoSimple } from '../../shared/components/dialogo-simple';
import { ItemFiscalizacion } from '../../models/item-fiscalizacion';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-planificacion',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './planificacion.html'
})


export class Planificacion implements OnInit {

  form!: FormGroup;
  concesionesSeleccionadas: Concesion[] = [];
  loading = false;

  constructor(
    private fb: FormBuilder,
    private fiscalizacionplanificar: FiscalizacionPlanificar,
    private globalService: Global,
    private router: Router,
    private dialog: MatDialog
  ) { }


  items: ItemFiscalizacion[] = [];
  errorMessage = '';

  ngOnInit(): void {

    this.cargarFormulario();

    this.form = this.fb.group({
      FCPlanificada: ['', Validators.required]
    });

    // Obtener concesiones desde servicio compartido
    this.concesionesSeleccionadas =
      this.fiscalizacionplanificar.getConcesionesSeleccionadas();
    console.log('concesionesSeleccionadas:', this.concesionesSeleccionadas);
    // Protección de ruta
    if (!this.concesionesSeleccionadas?.length) {
      this.router.navigate(['/fiscalizacion']);
      return;
    }

    this.form = this.fb.group({
      FCPlanificada: [null, Validators.required]
    });
  }

  cargarFormulario(): void {
    this.loading = true;
    this.globalService.obtenerItemsFiscalizacion().subscribe({
      next: (data) => {
        this.items = data;
        this.loading = false;
        console.log("formulario",this.items)
      },
      error: (err) => {
        this.errorMessage = 'Error al cargar los datos: ' + err.message;
        console.error(err);
        this.loading = false;
      }
    });
  }


  guardar() {

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const confirmDialog = this.dialog.open(DialogoSimple, {
      width: '400px',
      data: {
        titulo: 'Confirmación',
        mensaje: '¿Desea generar los formularios de fiscalización? Esto cambiara el estado de las CCMM a Planificada',
      }
    });

    confirmDialog.afterClosed().subscribe(confirmado => {

      if (!confirmado) return;

      const fecha = this.form.value.FCPlanificada;

      const payload: PlanificacionPayload = {
        CDReparticion: this.globalService.getReparticion(),
        NRRutUsuario: this.globalService.getRut(),
        FCPlanificada: fecha,
        detalles: this.concesionesSeleccionadas.map(c => ({
          IDConcesion: c.IDConcesion,
          FCFiscalizacion: fecha,
          CDTPEstadoPlan: 1,
          FCEjecucion: fecha
        }))
      };

      this.loading = true;

      this.fiscalizacionplanificar.crearPlanificacion(payload).subscribe({
        next: () => {

          this.loading = false;

          this.dialog.open(DialogoSimple, {
            data: {
              titulo: 'Éxito',
              mensaje: 'Planificación creada correctamente.',
              cancelar: false
            }
          }).afterClosed().subscribe(() => {
            this.router.navigate(['/fiscalizacion']);
          });

        },
        error: (err) => {
          this.loading = false;

          this.dialog.open(DialogoSimple, {
            data: {
              titulo: 'Error',
              mensaje: 'Ocurrió un error al crear la planificación.',
              cancelar: false
            }
          });

          console.error(err);
        }
      });
    });
  }


}
