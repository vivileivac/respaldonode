import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Fiscalizadores } from './fiscalizadores';

describe('Fiscalizadores', () => {
  let component: Fiscalizadores;
  let fixture: ComponentFixture<Fiscalizadores>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Fiscalizadores]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Fiscalizadores);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
