import { Component } from '@angular/core';

@Component({
  selector: 'app-fiscalizadores',
  imports: [],
  templateUrl: './fiscalizadores.html',
  styleUrl: './fiscalizadores.css',
})
export class Fiscalizadores {

}
