import { Component, AfterViewInit } from '@angular/core';
import flatpickr from 'flatpickr';

@Component({
  selector: 'app-fiscalizacion-realizada',
  templateUrl: './fiscalizacion-realizada.component.html',
  styleUrls: ['./fiscalizacion-realizada.component.css'] // corregido
})
export class FiscalizacionRealizadaComponent implements AfterViewInit {

  ngAfterViewInit() {
    // Inicializa flatpickr en el input de rango de fechas
    flatpickr("#filter-fecha-rango", {
      mode: "range",
      dateFormat: "d-m-Y"
    });
  }

}
