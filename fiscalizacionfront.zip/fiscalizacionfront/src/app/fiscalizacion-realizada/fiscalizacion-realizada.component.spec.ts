import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiscalizacionRealizadaComponent } from './fiscalizacion-realizada.component';

describe('FiscalizacionRealizadaComponent', () => {
  let component: FiscalizacionRealizadaComponent;
  let fixture: ComponentFixture<FiscalizacionRealizadaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FiscalizacionRealizadaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FiscalizacionRealizadaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
