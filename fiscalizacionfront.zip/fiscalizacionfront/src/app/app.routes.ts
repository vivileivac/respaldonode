import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FiscalizacionComponent } from './fiscalizacion/fiscalizacion.component';
import { FiscalizacionRealizadaComponent } from './fiscalizacion-realizada/fiscalizacion-realizada.component';
import { HeaderComponent } from './header/header.component';
import { FormularioComponent } from './formulario/formulario.component';
import { ReporteComponent } from './reporte/reporte.component';
import { FooterComponent } from './footer/footer.component';

export const routes: Routes = [
    {path: 'home', component:HomeComponent},
    {path: 'fiscalizacion', component: FiscalizacionComponent},
    {path: 'realizadas', component:FiscalizacionRealizadaComponent},
    {path: 'header', component:HeaderComponent},
    {path: 'formulario', component:FormularioComponent},
    {path: 'reporte', component:ReporteComponent},
    {path: 'footer', component:FooterComponent},
    {path: '**', redirectTo:'/home', pathMatch:'full'},        
];
