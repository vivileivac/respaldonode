import { Component } from '@angular/core';

@Component({
  selector: 'app-reporte',
  imports: [],
  templateUrl: './reporte.component.html',
  styleUrl: './reporte.component.css'
})
export class ReporteComponent {

}
