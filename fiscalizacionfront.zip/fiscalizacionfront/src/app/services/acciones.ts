import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Concesion } from '../models/concesion';

@Injectable({
  providedIn: 'root'
})
export class Acciones {

  // Estado interno
  private concesionesSeleccionadasSubject =
    new BehaviorSubject<Concesion[]>([]);

  // Observable público
  concesionesSeleccionadas$: Observable<Concesion[]> =
    this.concesionesSeleccionadasSubject.asObservable();

  constructor() {}

  // Setea la selección (desde cualquier componente)
  setConcesionesSeleccionadas(concesiones: Concesion[]): void {
    this.concesionesSeleccionadasSubject.next(concesiones);
  }

  // Obtiene el valor actual (uso puntual, sin subscribe)
  getConcesionesSeleccionadas(): Concesion[] {
    return this.concesionesSeleccionadasSubject.value;
  }

  // Limpia la selección (opcional, pero útil)
  clearConcesionesSeleccionadas(): void {
    this.concesionesSeleccionadasSubject.next([]);
  }
}
