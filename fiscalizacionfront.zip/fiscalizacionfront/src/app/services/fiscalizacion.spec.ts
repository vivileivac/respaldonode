import { TestBed } from '@angular/core/testing';

import { Fiscalizacion } from './fiscalizacion';

describe('Fiscalizacion', () => {
  let service: Fiscalizacion;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Fiscalizacion);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
