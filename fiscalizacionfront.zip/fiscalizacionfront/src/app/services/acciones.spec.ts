import { TestBed } from '@angular/core/testing';

import { Acciones } from './acciones';

describe('Acciones', () => {
  let service: Acciones;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Acciones);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
