import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FiscalizacionService {

  private baseUrl = environment.UrlBack;

  constructor(private http: HttpClient) {}

  recuperarBoard(repa: any): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}api/recuperar/board/${repa}`);
  }
}
