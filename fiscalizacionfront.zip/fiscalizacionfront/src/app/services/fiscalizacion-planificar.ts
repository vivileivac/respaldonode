import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Concesion } from '../models/concesion';

@Injectable({
  providedIn: 'root',
})
export class FiscalizacionPlanificar {

  private baseUrl = environment.UrlBack;

  constructor(private http: HttpClient) {}

  // ==========================
  // SECCIÓN HTTP
  // ==========================

  recuperarBoard(repa: any): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.baseUrl}api/recuperar/board/${repa}`
    );
  }

  crearPlanificacion(payload: any): Observable<any> {
    return this.http.post<any>(
      `${this.baseUrl}api/planificacion/crear`,
      payload
    );
  }

  // ==========================
  // ESTADO COMPARTIDO
  // ==========================

  private concesionesSeleccionadasSubject =
    new BehaviorSubject<Concesion[]>([]);

  concesionesSeleccionadas$ =
    this.concesionesSeleccionadasSubject.asObservable();

  setConcesionesSeleccionadas(concesiones: Concesion[]): void {
    this.concesionesSeleccionadasSubject.next(concesiones);
  }

  getConcesionesSeleccionadas(): Concesion[] {
    return this.concesionesSeleccionadasSubject.value;
  }

  clearConcesionesSeleccionadas(): void {
    this.concesionesSeleccionadasSubject.next([]);
  }
}
