import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { UsuarioGlobal } from '../models/usuario-global';
import { ItemFiscalizacion } from '../models/item-fiscalizacion';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root',
})
export class Global {

  private baseUrl = environment.UrlBack;

  constructor(private http: HttpClient, private router: Router) { }

  private usuario: UsuarioGlobal = {
    CDReparticion: 0,
    NRRutUsuario: 0
  };

  setUsuario(data: UsuarioGlobal) {
    this.usuario = data;
  }

  getUsuario(): UsuarioGlobal {
    return this.usuario;
  }

  getReparticion(): number {
    return this.usuario.CDReparticion;
  }

  getRut(): number {
    return this.usuario.NRRutUsuario;
  }

// obtener items del formulario de fiscalizacion
  obtenerItemsFiscalizacion(): Observable<ItemFiscalizacion[]> {
    return this.http.get<ItemFiscalizacion[]>(`${this.baseUrl}api/recuperar/formulario`);
  }
}

