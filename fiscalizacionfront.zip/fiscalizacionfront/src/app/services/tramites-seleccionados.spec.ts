import { TestBed } from '@angular/core/testing';

import { TramitesSeleccionados } from './tramites-seleccionados';

describe('TramitesSeleccionados', () => {
  let service: TramitesSeleccionados;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TramitesSeleccionados);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
