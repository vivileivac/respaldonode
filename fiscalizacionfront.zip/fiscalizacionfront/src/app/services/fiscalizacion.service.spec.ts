import { TestBed } from '@angular/core/testing';

import { FiscalizacionService } from './fiscalizacion.service';

describe('FiscalizacionService', () => {
  let service: FiscalizacionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FiscalizacionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
