import { Component } from '@angular/core';

@Component({
  selector: 'app-ingreso',
  imports: [],
  templateUrl: './ingreso.html',
  styleUrl: './ingreso.css',
})
export class Ingreso {

}
